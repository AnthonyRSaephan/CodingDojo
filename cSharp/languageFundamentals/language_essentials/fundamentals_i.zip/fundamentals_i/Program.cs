﻿//! 1
// for(int i = 1; i <= 255; i++){
//     System.Console.WriteLine(i);
// }

//! 2
// Random rand = new Random();
// for(int i = 0; i < 5; i++){
//     System.Console.WriteLine(rand.Next(10, 21));
// }

//! 3
// Random rand = new Random();
// int sum = 0;
// for(int i = 0; i < 5; i++){
//     sum += rand.Next(10, 21);
// }
// System.Console.WriteLine(sum);

//! 4
// for(int i = 1; i <= 100; i++){
//     if(i % 3 == 0 || i % 5 == 0){
//         if(!(i % 3 == 0 && i % 5 == 0)){
//             System.Console.WriteLine(i);
//         }
//     }
// }

//! 5 / 6
// for (int i = 1; i <= 100; i++)
// {
//     if (i % 3 == 0 && i % 5 == 0)
//     {
//         System.Console.WriteLine("FizzBuzz");
//     } else if(i % 3 == 0){
//         System.Console.WriteLine("Fizz");
//     }else if(i % 5 == 0){
//         System.Console.WriteLine("Buzz");
//     }
// }
